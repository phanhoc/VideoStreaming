
package com.example.ffmpegav;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.example.opencv.Motiondetect;
import com.example.serialport.SerialPortActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;

public class AVThread extends Thread 
    {
	Motiondetect motion;
    private final static String TAG = "FFMpeg::AVThread";
    private final static int AUDIO_DATA_ID = 1;
    private final static int VIDEO_DATA_ID = 2;
    private final static int AVCODEC_MAX_AUDIO_FRAME_SIZE = 200000;
    private int mFpsCounter = 0;
    private long mLastTime = System.currentTimeMillis();

    public static Bitmap mBackground;
    public static Bitmap mbitmap;
    //holds the current audio data after nativeDecodeFrameFromFile() returns AUDIO_DATA_ID
    private byte[] mAudioFrameBuffer = new byte[AVCODEC_MAX_AUDIO_FRAME_SIZE];
    //holds the current audio data length after nativeDecodeFrameFromFile() returns AUDIO_DATA_ID
    private int[] mAudioFrameBufferDataLength = new int[1];
    private AudioTrack mAudioTrack = null;
    private Handler mHandler;
    private boolean mRun;
    private boolean mVideoOpened;
    private boolean mAudioOpened;
    private SurfaceHolder mSurfaceHolder;
    Paint paint = new Paint();
    private int x;
    private int y;
    private int toado[];
    private String url;
    public AVThread(SurfaceHolder aSurfaceHolder, Context aContext, Handler aHandler)
        {
    	//url="http://192.168.11.163:12345/video2.mjpg";
    	url="rtsp://192.168.11.163:554/live.sdp";
    	paint.setColor(Color.RED);
    	paint.setStyle(Paint.Style.STROKE);
        mSurfaceHolder = aSurfaceHolder;
        mHandler = aHandler;
        toado=new int[2];
        //ARGB_8888 == PIX_FMT_RGBA
        //RGB_565 == PIX_FMT_RGB565LE
        //mbitmap= Bitmap.createBitmap(640,480,Bitmap.Config.ARGB_8888);
        mBackground = Bitmap.createBitmap(640,480,Bitmap.Config.ARGB_8888); //ARGB_8888
        //mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100, AudioFormat.CHANNEL_CONFIGURATION_STEREO,
               // AudioFormat.ENCODING_PCM_16BIT, AVCODEC_MAX_AUDIO_FRAME_SIZE, AudioTrack.MODE_STREAM);

        //modify path and file name to mach your sample
       
        if (nativeOpenFromFile(url) != 0)
            {
            nativeClose();
            Log.i(TAG, "nativeOpen() failed, throwing RuntimeException");
            throw new RuntimeException();
            }
        
         try {
        	// motion=new Motiondetect();
			//Server.start(12345);
			// Motiondetect.start();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    }
        //since both video and audio are optional here, we try them in turn
        //if both were required, we could use just one check like this:
        //if (nativeOpen(Environment.getExternalStorageDirectory().getAbsolutePath() + "/mediafilename") != 0
        //    || nativeOpenVideo(mBackground) != 0
        //    || nativeOpenAudio(mAudioFrameBuffer, mAudioFrameBufferDataLength) != 0)
        //    {
        //    nativeClose();
        //    throw new RuntimeException();
        //    }

        mVideoOpened = nativeOpenVideo(mBackground) == 0;
       // mVideoOpened=nativeOpenVideo(mbitmap)==0;
        if (!mVideoOpened)
            nativeCloseVideo();

       // mAudioOpened = nativeOpenAudio(mAudioFrameBuffer, mAudioFrameBufferDataLength) == 0;
//        if (!mAudioOpened)
//            nativeCloseAudio();

        if (!mVideoOpened)
            {
            Log.i(TAG, "unable to open a stream, throwing RuntimeException");
            throw new RuntimeException();
            }
        }

    public void run()
        {
        Log.i(TAG, "entering run()");

        mRun = true;
      //  mAudioTrack.play();

        while (mRun)
            {
            int dispatch = 0;
            synchronized (mSurfaceHolder)
                {
            	//video can be closed and reopened by setSurfaceSize()
            	//we therefore call all video processing from within the synchronisation block
            	//we also re-check mRun within the block to make sure video has been reopened successfully.
            	//nativeDecodeFrameFromFile() groups audio & video - since no other thread accesses audio
            	//it could theoretically be moved out of the synchronisation block - requiring a split
            	//of nativeDecodeFrameFromFile()'s functionality
            	if (mRun)
            		{
            		dispatch = nativeDecodeFrameFromFile();
                    while(dispatch==-1)
                    {
            		 dispatch=nativeOpenFromFile(url);
            		 System.out.println("ENd of file");
                    }
       
            		
            		if (dispatch == VIDEO_DATA_ID)
	                    {
            			Canvas canvas = null;
	                    try {
	                        canvas = mSurfaceHolder.lockCanvas(null);    
	                        nativeUpdateBitmap();
	       			        toado=Start(mBackground);
	                        canvas.drawBitmap(mBackground, 0, 0, null);
	                        if(toado[0]!=320)
	                       {
	                        RectF rect=new RectF(toado[0]-50,toado[1]-100,toado[0]+50,toado[1]+100);
							canvas.drawRoundRect(rect,0,0, paint);
	                        }
	                        }
	                    finally
	                        {
	                        if (canvas != null)
	                            {
	                            mSurfaceHolder.unlockCanvasAndPost(canvas);
	                            }
	                        }
            		}
                }
            }
            }
        synchronized (mSurfaceHolder)
            {
            nativeClose();
            }
        Log.i(TAG, "leaving run()");
        }
	public void finish()
        {
    	Log.i(TAG, "finish()");
        mRun = false;
        }

    public void sendText(String aText)
        {
        int vis = View.INVISIBLE;
        if (aText.length() > 0) //isEmpty() supported from API level 9
            {
            vis = View.VISIBLE;
            }

        Message msg = mHandler.obtainMessage();
        Bundle b = new Bundle();
        b.putString("text", aText);
        b.putInt("viz", vis);
        msg.setData(b);
        mHandler.sendMessage(msg);
        }

    public void setSurfaceSize(int aWidth, int aHeight)
        {
        synchronized (mSurfaceHolder)
            {
            mBackground = Bitmap.createScaledBitmap(mBackground,aWidth,aHeight, true);
            if (mVideoOpened)
            	{
            	//free old references to mBackground and other video resources
	            nativeCloseVideo();
	            mVideoOpened = nativeOpenVideo(mBackground) == 0;
	           // mVideoOpened = nativeOpenVideo(mbitmap) == 0;
	            if (!mVideoOpened)
	                {
	            	nativeCloseVideo();
	                Log.i(TAG, "unable to reopen video");
	                finish();
	                }
            	}
            }
        }
    public static Bitmap getbitmap()
    {
    	return mBackground;
    }
    //native methods are described in jni/avjni.c
  //  private static native void Start(Bitmap aBitmap);
    private static native int[] Start(Bitmap abitmap);
    //private static native void Start(Bitmap aBitmap);
    private native int nativeOpenFromFile(String aMediaFile);
    private native void nativeClose();
    private native int nativeOpenVideo(Object aBitmapRef);
    private native void nativeCloseVideo();
    //private native int (byte[] aAudioFrameBufferRef, int[] aAudioFrameBufferCountRef);
    private native void nativeCloseAudio();
    private native int nativeDecodeFrameFromFile(); //never touch the bitmap here
    private native int nativeUpdateBitmap();
    private native void openFile(String url);
    private native void drawFrame(Bitmap bmp);
    };

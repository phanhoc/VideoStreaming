
package com.example.ffmpegav;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;

class AVView extends SurfaceView implements SurfaceHolder.Callback
    {
	//private final static String TAG = "FFMpeg::AVView";

    private TextView mTextView;
    private AVThread mThread;

    public AVView(Context aContext, AttributeSet aAttrs)
        {
        super(aContext, aAttrs);

        getHolder().addCallback(this); //register SurfaceHolder.Callback
        getHolder().setKeepScreenOn(true); //keep screen on when this SurfaceView is displayed
        }

    public void setTextView(TextView aTextView)
        {
        mTextView = aTextView;
        }

    //SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder aHolder, int aFormat, int aWidth, int aHeight)
        {
        mThread.setSurfaceSize(aWidth, aHeight);
        }

    //SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder aHolder)
        {
        mThread = new AVThread(aHolder, getContext(), new Handler()
            {
            public void handleMessage(Message m)
                {
                mTextView.setVisibility(m.getData().getInt("viz"));
                mTextView.setText(m.getData().getString("text"));
                }
            });

        mThread.start();
        }

    //SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder aHolder)
        {
        mThread.finish();
        try {
            mThread.join();
            }
        catch (InterruptedException e)
            {
            }
           
        }

    };

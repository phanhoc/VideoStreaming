package com.example.ffmpegav;

import java.io.IOException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import com.example.serialport.*;
public class FFMpegAV extends Activity
    {
	private final static String TAG = "FFMpeg::FFMpegAV";
    private AVView mVideoView;
    SerialPortActivity serial;
public void onCreate(Bundle savedInstanceState)
    {
	Log.i(TAG, "bat dau");
	
    super.onCreate(savedInstanceState);
    Intent intent = new Intent(FFMpegAV.this,SerialPortActivity.class);
    startService(intent);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

    setContentView(R.layout.main);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    
    mVideoView = (AVView)findViewById(R.id.video);
    mVideoView.setTextView((TextView)findViewById(R.id.text));
    
    
    }

    public void onConfigurationChanged(Configuration newConfig)
        {
        Log.i(TAG, "onConfigurationChanged()");
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        super.onConfigurationChanged(newConfig);
        }

	public void onStart() {
    	super.onStart();
    	Log.i(TAG,"ok");
    	serial=new SerialPortActivity();
    	serial.start();
	}
	 @Override
		protected void onDestroy() {
	    	System.out.println("huy");
	    	serial.finish();
			super.onDestroy();
		}
    static {
    	System.loadLibrary("avjni");
    	System.loadLibrary("opencv");
    	}
    };


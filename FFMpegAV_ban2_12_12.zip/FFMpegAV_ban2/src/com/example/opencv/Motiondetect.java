package com.example.opencv;
/* ------------------
   Server
   usage: java Server [RTSP listening port]
   ---------------------- */


import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.example.ffmpegav.AVThread;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.widget.TextView;

public class Motiondetect implements Runnable{

	Timer timer; // timer used to send the images at the video frame rate
	static int FRAME_PERIOD =100; 
	byte[] buf; // buffer used to store the images to send to the client
     AVThread avvideo;
	private Bitmap mBitmap;
	private static Bitmap outBitmap;
	private int mSecs = 0;
	final static String CRLF = "\r\n";
	static
	{
		System.loadLibrary("opencv");
	}
    private static native void Start(Bitmap aBitmap);
	//private static native byte[] Start(Bitmap aBitmap);
	public Motiondetect() 
	{
		//buf = new byte[150000];
		// init Timer
		//timer = new Timer(FRAME_PERIOD, this);
		//timer.setInitialDelay(0);
		//timer.setCoalesce(true);
		
		// Inicializa um temporizador
		//avvideo=new AVThread(aSurfaceHolder, aContext, aHandler)

		// allocate memory for the sending buffer
		//buf = new byte[150000];
		mBitmap = Bitmap.createBitmap(320,240, Bitmap.Config.ARGB_8888);
		outBitmap = Bitmap.createBitmap(320, 240, Bitmap.Config.ARGB_8888);
		// buf = mBitmap.toByteArray();
		//s=new String();
		// Handler to close the main window
		//addWindowListener(new WindowAdapter() {
		//	public void windowClosing(WindowEvent e) {
		//		// stop the timer and exit
		//		timer.stop();
		//		System.exit(0);
		//	}
		//});

		// GUI:
		//label = new JLabel("Send frame #        ", JLabel.CENTER);
		//getContentPane().add(label, BorderLayout.CENTER);
	}

	// ------------------------
	// Handler for timer
	// ------------------------
	public void run() {
		 mBitmap=avvideo.getbitmap();
		 Start(mBitmap);
		 //AVThread.mBackground = BitmapFactory.decodeByteArray(imageData, 0,imageData.length);
	     System.out.println("xong");
	}
	public static Bitmap getbitmap()
    {
    	return outBitmap;
    }

	public static void start() throws Exception {
		
		final Motiondetect motion = new Motiondetect();
		///////////////////////
        //openFile("rtsp://192.168.0.102:554/live.sdp");
		////////////////////////
		//int RTSPport = porta;

		//ServerSocket listenSocket = new ServerSocket(RTSPport);
		//theServer.RTSPsocket = listenSocket.accept();
		//listenSocket.close();

		//theServer.ClientIPAddr = theServer.RTSPsocket.getInetAddress();

		// Inicializa o estado do RTP
		//state = INIT;
		
		//ac.log("IP do cliente: " + theServer.ClientIPAddr.getHostAddress() + "\n");
		
		//return;

		
		// Define streams de entrada e saida
		//RTSPBufferedReader = new BufferedReader(new InputStreamReader(theServer.RTSPsocket.getInputStream()));
		//RTSPBufferedWriter = new BufferedWriter(new OutputStreamWriter(theServer.RTSPsocket.getOutputStream()));

		// Aguarda por uma mensagem de SETUP do cliente
		//int request_type;
//		boolean done = false;
//		while (!done) {
//			request_type = theServer.parse_RTSP_request(); // bloqueado
//			System.out.println("Qua");
//			if (request_type == SETUP) {
//				done = true;
//				// atualiza o estado do RTSP
//				state = READY;
//				System.out.println("Novo estado RTSP: READY");
//
//				// Envia uma resposta
//				theServer.send_RTSP_response();
//
//				// Inicializa um objeto de VideoStream
//				try {
//					//theServer.video = new VideoStream(VideoFileName);
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//
//				// Inicializa um socket RTP
//				try {
//					theServer.RTPsocket = new DatagramSocket();
//				} catch (SocketException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		}

		final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
		new Thread(new Runnable() {
			private ScheduledFuture sf;
			
			@Override
			public void run() {
					
				System.out.println("chay");
				int request_type;
			
			    // reconhece o tipo de requisi��o
				//request_type = theServer.parse_RTSP_request(); // bloqueado
				
	
				//if ((request_type == PLAY) && (state == READY)) {
				//	System.out.println("Qua day");
					// envia uma resposta de volta
				//	theServer.send_RTSP_response();
					// inicia um temporizador
					
					sf = scheduler.scheduleAtFixedRate(motion, 0, FRAME_PERIOD, TimeUnit.MILLISECONDS);
					
					// atualiza o estado do RTSP
					//state = PLAYING;
					//System.out.println("Novo estado RTSP: PLAYING");
				//}
				//else if ((request_type == PAUSE) && (state == PLAYING)) {
				//	System.out.println("Qua day 1");
					// envia uma resposta de volta
				//	theServer.send_RTSP_response();
					// para o temporizador
					//theServer.timer.stop();
				//	try {
					//	System.out.println("Qua day 3");
						//scheduler.awaitTermination(500, TimeUnit.MILLISECONDS);
					    //theServer.wait();
					//	sf.wait(500);
				//	} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
				//	}
					//scheduler.shutdown();
					// atualiza o estado do RTSP
					//state = READY;
					//System.out.println("Novo estado RTSP: READY");
				//}
				//else if (request_type == TEARDOWN) {
					// envia uma resposta de volta
				//	theServer.send_RTSP_response();
					// para o temporizador
					//theServer.timer.stop();
					//scheduler.shutdownNow();
					
					// fecha os sockets
					//try {
						//theServer.wait();
					//	sf.cancel(false);
					//	theServer.RTSPsocket.close();
				//	} catch (IOException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
				//	}
				//	theServer.RTPsocket.close();
					
					//encerra a aplica��o
				//	System.exit(0);
				//}
			}
			
		}).start();
		
	}

}
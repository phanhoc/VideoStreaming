/*
 * Copyright 2009 Cedric Priscal
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

package com.example.serialport;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidParameterException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.MergeCursor;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;


public class SerialPortActivity{
	private final static String TAG = "Serialportactivity";
	private Application mApplication;
	private  SerialPort mSerialPort;
	private  OutputStream mOutputStream;
	private  InputStream mInputStream;
	private  ReadThread mReadThread;
	private  String mess;
	private String serialpath;
	private int baudrate;
	private class ReadThread extends Thread {
      
		@Override
		public void run() {
			super.run();
			System.out.println("chay 1");
			while(!isInterrupted()) {
				//System.out.println("chay");
				int size;
				
				try {
					byte[] buffer = new byte[32];
					if (mInputStream == null) return;
					//try {
					//	mInputStream.
					//} catch (InterruptedException e) {
						// TODO Auto-generated catch block
					//	e.printStackTrace();
					//}
					size = mInputStream.read(buffer);
					if (size>0) {
						onDataReceived(buffer, size);
					}
				} catch (IOException e) {
					e.printStackTrace();
					return;
				}
			}
		}
	}
    public SerialPortActivity()
    {
    	serialpath="/dev/ttyS1";
    	baudrate=19200;
    }
    public void finish()
    {
	Log.i(TAG, "finish()");
	if (mReadThread != null)
		mReadThread.interrupt();
	   // mReadThread.stop();
		if (mSerialPort != null) {
			mSerialPort.close();
			mSerialPort = null;
		}
		
		//mSerialPort = null;
		
	}
//	private void DisplayError(int resourceId) {
//		AlertDialog.Builder b = new AlertDialog.Builder(this);
//		b.setTitle("Error");
//		b.setMessage(resourceId);
//		b.setPositiveButton("OK", new OnClickListener() {
//			public void onClick(DialogInterface dialog, int which) {
//				//SerialPortActivity.this.finish();
//			}
//		});
//		b.show();
//	}

	public void start() {
		//super.onCreate();
		System.out.println("haha");
		//mApplication = (Application) getApplication();
		//try {
		//	Log.i(TAG,"Ok");
			try {
				mSerialPort=new SerialPort(new File(serialpath),baudrate);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//mSerialPort = mApplication.getSerialPort();
			mOutputStream = mSerialPort.getOutputStream();
			mInputStream = mSerialPort.getInputStream();

			/* Create a receiving thread */
			mReadThread = new ReadThread();
			mReadThread.start();
		///} catch (SecurityException e) {
			//DisplayError(R.string.error_security);
		//} catch (IOException e) {
			//DisplayError(R.string.error_unknown);
		//} catch (InvalidParameterException e) {
			//DisplayError(R.string.error_configuration);
		//}
	}

	protected  void onDataReceived(final byte[] buffer, final int size)
	{
		System.out.println(size);
		byte[] data=new byte[size];
		int i=0;
		for(i=0;i<size;i++)
		data[i]=buffer[i];
		//data[size]='\0';
		try {
			mess = new String(data,"UTF-8");
		} catch (UnsupportedEncodingException e) 
		{
			e.printStackTrace();
		}
		System.out.println("data:"+mess);
	}
	
	
	
}
